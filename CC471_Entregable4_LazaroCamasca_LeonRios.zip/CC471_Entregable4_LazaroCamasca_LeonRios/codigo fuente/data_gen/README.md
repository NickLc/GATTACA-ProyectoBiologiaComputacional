# Fuentes
Se utilizará la proteina [NADH dehidrogenasa, subunidad 2](https://es.wikipedia.org/wiki/NADH_deshidrogenasa).

## Especies

+ [Tremarctos ornatus](https://www.ncbi.nlm.nih.gov/protein/ABM63279.1)
+ [Panthera onca](https://www.ncbi.nlm.nih.gov/protein/AIY56286.1)
+ [Vicugna vicugna](https://www.ncbi.nlm.nih.gov/protein/ACJ45788.1)
+ [Aulacorhynchus huallagae](https://www.ncbi.nlm.nih.gov/protein/329756060)
+ [Leopardus jacobita](https://www.ncbi.nlm.nih.gov/protein/YP_009178568.1)
+ [Inia geoffrensis](https://www.ncbi.nlm.nih.gov/protein/NP_944712.1)
+ [Spheniscus humboldti](https://www.ncbi.nlm.nih.gov/protein/AON77377.1)
+ [Vultur gryphus](https://www.ncbi.nlm.nih.gov/protein/AEH42425.1)
+ [Lama glama](https://www.ncbi.nlm.nih.gov/protein/BAH23368.1)
+ [Cavia porcellus](https://www.ncbi.nlm.nih.gov/protein/AJE26518.1)
+ [Platalea ajaja](https://www.ncbi.nlm.nih.gov/protein/298371651)
