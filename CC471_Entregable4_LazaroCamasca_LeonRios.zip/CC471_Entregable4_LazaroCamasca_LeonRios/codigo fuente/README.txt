# Programa GATTACA

Para poder replicar el proyecto se tienen que ejecutar el archivo graphics.py
`python graphics.py`

Este script contiene la interfaz grafica y hace uso de la libreria Bio_Tool.py para implemetar las acciones de los botones.


## Modelamiento 3D

Ejecutar el cuaderno `Modelamiento 3D Proteina` que se encuenta en la carpeta Modelamiento 3D
